package com.example.clinic.service;
import org.springframework.stereotype.Service;
import java.util.List; import java.util.Optional;
import com.example.clinic.repository.DepartmentRepository;
import com.example.clinic.model.Department;
import lombok.RequiredArgsConstructor;

@Service @RequiredArgsConstructor
public class DepartmentService {
  private final DepartmentRepository repo;
  public List<Department> findAll(){ return repo.findAll(); }
  public Optional<Department> findById(Long id){ return repo.findById(id); }
  public Department save(Department e){ return repo.save(e); }
  public void delete(Long id){ repo.deleteById(id); }
}
