package com.example.clinic.controller;
import org.springframework.stereotype.Controller; 
import org.springframework.ui.Model; 
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*; 
import lombok.RequiredArgsConstructor;
import jakarta.validation.Valid;
import com.example.clinic.model.Doctor;
import com.example.clinic.service.DoctorService;

@Controller @RequiredArgsConstructor
@RequestMapping("/doctors")
public class DoctorController {
  private final DoctorService service;

  @GetMapping public String list(Model model){ model.addAttribute("doctors", service.findAll()); return "doctors/list"; }

  @GetMapping("/create") public String create(Model model){ model.addAttribute("doctor", new Doctor()); return "doctors/form"; }

  @PostMapping("/save") public String save(@ModelAttribute("doctor") @Valid Doctor obj, BindingResult br){ 
    if(br.hasErrors()) return "doctors/form"; 
    service.save(obj); return "redirect:/doctors"; 
  }

  @GetMapping("/edit/{id}") public String edit(@PathVariable Long id, Model model){ 
    return service.findById(id).map(e->{ model.addAttribute("doctor", e); return "doctors/form"; }).orElse("redirect:/doctors"); 
  }

  @GetMapping("/delete/{id}") public String delete(@PathVariable Long id){ service.delete(id); return "redirect:/doctors"; }

  @GetMapping("/view/{id}") public String view(@PathVariable Long id, Model model){ 
    return service.findById(id).map(e->{ model.addAttribute("doctor", e); return "doctors/view"; }).orElse("redirect:/doctors"); 
  }
}
