package com.example.clinic.controller;
import org.springframework.stereotype.Controller; 
import org.springframework.ui.Model; 
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*; 
import lombok.RequiredArgsConstructor;
import jakarta.validation.Valid;
import com.example.clinic.model.Appointment;
import com.example.clinic.service.AppointmentService;

@Controller @RequiredArgsConstructor
@RequestMapping("/appointments")
public class AppointmentController {
  private final AppointmentService service;

  @GetMapping public String list(Model model){ model.addAttribute("appointments", service.findAll()); return "appointments/list"; }

  @GetMapping("/create") public String create(Model model){ model.addAttribute("appointment", new Appointment()); return "appointments/form"; }

  @PostMapping("/save") public String save(@ModelAttribute("appointment") @Valid Appointment obj, BindingResult br){ 
    if(br.hasErrors()) return "appointments/form"; 
    service.save(obj); return "redirect:/appointments"; 
  }

  @GetMapping("/edit/{id}") public String edit(@PathVariable Long id, Model model){ 
    return service.findById(id).map(e->{ model.addAttribute("appointment", e); return "appointments/form"; }).orElse("redirect:/appointments"); 
  }

  @GetMapping("/delete/{id}") public String delete(@PathVariable Long id){ service.delete(id); return "redirect:/appointments"; }

  @GetMapping("/view/{id}") public String view(@PathVariable Long id, Model model){ 
    return service.findById(id).map(e->{ model.addAttribute("appointment", e); return "appointments/view"; }).orElse("redirect:/appointments"); 
  }
}
