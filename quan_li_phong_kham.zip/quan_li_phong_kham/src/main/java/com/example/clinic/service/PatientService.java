package com.example.clinic.service;
import org.springframework.stereotype.Service;
import java.util.List; import java.util.Optional;
import com.example.clinic.repository.PatientRepository;
import com.example.clinic.model.Patient;
import lombok.RequiredArgsConstructor;

@Service @RequiredArgsConstructor
public class PatientService {
  private final PatientRepository repo;
  public List<Patient> findAll(){ return repo.findAll(); }
  public Optional<Patient> findById(Long id){ return repo.findById(id); }
  public Patient save(Patient e){ return repo.save(e); }
  public void delete(Long id){ repo.deleteById(id); }
}
