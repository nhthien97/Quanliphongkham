package com.example.clinic.service;
import org.springframework.stereotype.Service;
import java.util.List; import java.util.Optional;
import com.example.clinic.repository.PaymentRepository;
import com.example.clinic.model.Payment;
import lombok.RequiredArgsConstructor;

@Service @RequiredArgsConstructor
public class PaymentService {
  private final PaymentRepository repo;
  public List<Payment> findAll(){ return repo.findAll(); }
  public Optional<Payment> findById(Long id){ return repo.findById(id); }
  public Payment save(Payment e){ return repo.save(e); }
  public void delete(Long id){ repo.deleteById(id); }
}
