package com.example.clinic.service;
import org.springframework.stereotype.Service;
import java.util.List; import java.util.Optional;
import com.example.clinic.repository.DoctorRepository;
import com.example.clinic.model.Doctor;
import lombok.RequiredArgsConstructor;

@Service @RequiredArgsConstructor
public class DoctorService {
  private final DoctorRepository repo;
  public List<Doctor> findAll(){ return repo.findAll(); }
  public Optional<Doctor> findById(Long id){ return repo.findById(id); }
  public Doctor save(Doctor e){ return repo.save(e); }
  public void delete(Long id){ repo.deleteById(id); }
}
