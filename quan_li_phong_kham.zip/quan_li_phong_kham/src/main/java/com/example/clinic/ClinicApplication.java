package com.example.clinic;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.clinic.model.*;
import com.example.clinic.repository.*;

import java.time.LocalDate;
import java.util.List;

@SpringBootApplication
public class ClinicApplication {
    public static void main(String[] args){ SpringApplication.run(ClinicApplication.class, args); }

    @Bean
    CommandLineRunner seed(
            PatientRepository patientRepo,
            DoctorRepository doctorRepo,
            DepartmentRepository deptRepo,
            AppointmentRepository apptRepo,
            PaymentRepository payRepo
    ){
        return args -> {
            if (deptRepo.count() == 0) {
                deptRepo.saveAll(List.of(
                        new Department(null,"Nội tổng hợp","Tầng 2"),
                        new Department(null,"Ngoại chấn thương","Tầng 3"),
                        new Department(null,"Tai mũi họng","Tầng 4"),
                        new Department(null,"Răng hàm mặt","Tầng 5"),
                        new Department(null,"Nhi khoa","Tầng 2"),
                        new Department(null,"Tim mạch","Tầng 6"),
                        new Department(null,"Da liễu","Tầng 5"),
                        new Department(null,"Sản phụ","Tầng 7"),
                        new Department(null,"Mắt","Tầng 4"),
                        new Department(null,"Thần kinh","Tầng 6")
                ));
            }
            if (doctorRepo.count() == 0) {
                var deps = deptRepo.findAll();
                doctorRepo.saveAll(List.of(
                        new Doctor(null,"Nguyễn An",deps.get(0),"Sáng"),
                        new Doctor(null,"Trần Bình",deps.get(1),"Chiều"),
                        new Doctor(null,"Lê Cẩm",deps.get(2),"Tối"),
                        new Doctor(null,"Phạm Dũng",deps.get(3),"Sáng"),
                        new Doctor(null,"Vũ Em",deps.get(4),"Chiều"),
                        new Doctor(null,"Phan Giai",deps.get(5),"Tối"),
                        new Doctor(null,"Đoàn Hà",deps.get(6),"Sáng"),
                        new Doctor(null,"Bùi Ích",deps.get(7),"Chiều"),
                        new Doctor(null,"Huỳnh Kha",deps.get(8),"Tối"),
                        new Doctor(null,"Đặng Lan",deps.get(9),"Sáng")
                ));
            }
            if (patientRepo.count() == 0) {
                patientRepo.saveAll(List.of(
                        new Patient(null,"Phạm Nam",28,"Nam","BN001"),
                        new Patient(null,"Nguyễn Hoa",31,"Nữ","BN002"),
                        new Patient(null,"Trần Phong",22,"Nam","BN003"),
                        new Patient(null,"Lê Mai",26,"Nữ","BN004"),
                        new Patient(null,"Đỗ Khải",35,"Nam","BN005"),
                        new Patient(null,"Đinh Vân",29,"Nữ","BN006"),
                        new Patient(null,"Bùi Lâm",41,"Nam","BN007"),
                        new Patient(null,"Vũ Anh",19,"Nữ","BN008"),
                        new Patient(null,"Hoàng Việt",33,"Nam","BN009"),
                        new Patient(null,"Đào Hạ",27,"Nữ","BN010")
                ));
            }
            if (apptRepo.count() == 0) {
                var p = patientRepo.findAll();
                var d = doctorRepo.findAll();
                apptRepo.saveAll(List.of(
                        new Appointment(null,p.get(0),d.get(0), LocalDate.now().plusDays(1),"Mới"),
                        new Appointment(null,p.get(1),d.get(1), LocalDate.now().plusDays(2),"Mới"),
                        new Appointment(null,p.get(2),d.get(2), LocalDate.now().plusDays(3),"Xác nhận"),
                        new Appointment(null,p.get(3),d.get(3), LocalDate.now().plusDays(1),"Xác nhận"),
                        new Appointment(null,p.get(4),d.get(4), LocalDate.now().plusDays(5),"Hoàn thành"),
                        new Appointment(null,p.get(5),d.get(5), LocalDate.now().plusDays(1),"Mới"),
                        new Appointment(null,p.get(6),d.get(6), LocalDate.now().plusDays(2),"Mới"),
                        new Appointment(null,p.get(7),d.get(7), LocalDate.now().plusDays(3),"Xác nhận"),
                        new Appointment(null,p.get(8),d.get(8), LocalDate.now().plusDays(1),"Hoàn thành"),
                        new Appointment(null,p.get(9),d.get(9), LocalDate.now().plusDays(4),"Mới")
                ));
            }
            if (payRepo.count() == 0) {
                var p = patientRepo.findAll();
                payRepo.saveAll(List.of(
                        new Payment(null,p.get(0),500000.0,"Đã thanh toán"),
                        new Payment(null,p.get(1),650000.0,"Chưa thanh toán"),
                        new Payment(null,p.get(2),450000.0,"Đã thanh toán"),
                        new Payment(null,p.get(3),300000.0,"Chưa thanh toán"),
                        new Payment(null,p.get(4),250000.0,"Đã thanh toán"),
                        new Payment(null,p.get(5),780000.0,"Chưa thanh toán"),
                        new Payment(null,p.get(6),1200000.0,"Đã thanh toán"),
                        new Payment(null,p.get(7),990000.0,"Chưa thanh toán"),
                        new Payment(null,p.get(8),210000.0,"Đã thanh toán"),
                        new Payment(null,p.get(9),320000.0,"Chưa thanh toán")
                ));
            }
        };
    }
}
