package com.example.clinic.controller;
import org.springframework.stereotype.Controller; 
import org.springframework.ui.Model; 
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*; 
import lombok.RequiredArgsConstructor;
import jakarta.validation.Valid;
import com.example.clinic.model.Payment;
import com.example.clinic.service.PaymentService;

@Controller @RequiredArgsConstructor
@RequestMapping("/payments")
public class PaymentController {
  private final PaymentService service;

  @GetMapping public String list(Model model){ model.addAttribute("payments", service.findAll()); return "payments/list"; }

  @GetMapping("/create") public String create(Model model){ model.addAttribute("payment", new Payment()); return "payments/form"; }

  @PostMapping("/save") public String save(@ModelAttribute("payment") @Valid Payment obj, BindingResult br){ 
    if(br.hasErrors()) return "payments/form"; 
    service.save(obj); return "redirect:/payments"; 
  }

  @GetMapping("/edit/{id}") public String edit(@PathVariable Long id, Model model){ 
    return service.findById(id).map(e->{ model.addAttribute("payment", e); return "payments/form"; }).orElse("redirect:/payments"); 
  }

  @GetMapping("/delete/{id}") public String delete(@PathVariable Long id){ service.delete(id); return "redirect:/payments"; }

  @GetMapping("/view/{id}") public String view(@PathVariable Long id, Model model){ 
    return service.findById(id).map(e->{ model.addAttribute("payment", e); return "payments/view"; }).orElse("redirect:/payments"); 
  }
}
