package com.example.clinic.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import com.example.clinic.service.PatientService;

@Controller @RequiredArgsConstructor
public class HomeController {
  private final PatientService patientService;
  @GetMapping("/") public String index(Model model){ model.addAttribute("patients", patientService.findAll()); return "index"; }
}
