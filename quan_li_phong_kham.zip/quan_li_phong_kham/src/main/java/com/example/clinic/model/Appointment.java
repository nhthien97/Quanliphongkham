package com.example.clinic.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
@Entity @Data @NoArgsConstructor @AllArgsConstructor
public class Appointment {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name="patient_id")
  @ToString.Exclude private Patient patient;
  @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name="doctor_id")
  @ToString.Exclude private Doctor doctor;
  private LocalDate date;
  private String status;
}