# quan_li_phong_kham
Chạy với **Java 17** + **Spring Boot 3**.

## Build & Run
```bash
mvn clean package
java -jar target/quan-li-phong-kham-1.0.0.jar
```
- App: http://localhost:8080
- H2 console: http://localhost:8080/h2-console
  - JDBC URL: `jdbc:h2:mem:clinicdb`
  - user: `sa`, password: *(để trống)*

## Ghi chú
- Seed sẵn **10 bản ghi** cho từng bảng trong `ClinicApplication.seed()`.
